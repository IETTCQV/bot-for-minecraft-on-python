from . import types, colorama
from .buffer import PacketBuffer

from socket import socket as Socket, AF_INET, SOCK_STREAM
from threading import Thread
from time import sleep

import zlib

def PACK(buffer,num=None):
	data = buffer.bytes
	buffer.clear()
	types.VarInt.write(num if num != None else len(data),buffer)
	buffer.write(data)

def UNPACK():
	pass

class Main:
	def __init__(self):
		self.color = False
		self.listen_chat = None

	def connect(self,host='localhost',port=25565,username='PythonBot'):
		self.socket = Socket(AF_INET, SOCK_STREAM)
		try:
			self.socket.connect((host, port))
		except ConnectionRefusedError:
			raise SystemExit('Сервер не доступен')

		def send(buffer,packid):
			PACK(buffer)
			buffer.seek(0)
			types.VarInt.write(packid,buffer)
			PACK(buffer)
			self.socket.sendall(buffer.bytes)

		buffer = PacketBuffer()
		types.VarInt.write(754,buffer)
		types.String.write(host,buffer)
		types.UnsignedShort.write(port,buffer)
		types.VarInt.write(2,buffer)
		send(buffer,0x00)

		buffer = PacketBuffer()
		types.String.write(username,buffer)
		send(buffer,0x00)

		def recv(a=False):
			text = self.socket.recv(1024)
			buffer = PacketBuffer(text)
			buffer.seek(0)
			size = types.VarInt.read(buffer)
			if a:
				max_size = types.VarInt.read(buffer)
			packid = types.VarInt.read(buffer)
			data = buffer.read()
			return size,packid,data

		size,packid,data = recv()
		if packid == 0x03:
			buffer = PacketBuffer(data)
			buffer.seek(0)
			print(f'Максимальный размер до сжатия: {types.VarInt.read(buffer)}')
		else:
			raise SystemExit(f'Неверный пакет: {hex(packid)} вместо первого пакета 0x03\n{data}')

		size,packid,data = recv(True)
		if packid == 0x02:
			buffer = PacketBuffer(data[1:])
			buffer.seek(0)
			uuid = types.UUID.read(buffer)
			name = types.String.read(buffer)
			print('UUID пользователя: ' + uuid)
		else:
			raise SystemExit(f'Неверный пакет: {hex(packid)} вместо второго пакета 0x02\n{data}')

		Thread(target=self.recv,daemon=True).start()

	def send(self,buffer,packid):
		# zlib.compress()
		PACK(buffer)
		buffer.seek(0)
		types.VarInt.write(packid,buffer)
		PACK(buffer,0)
		PACK(buffer)
		self.socket.sendall(buffer.bytes)

	def recv(self):
		while True:
			try:
				data = self.socket.recv(1024*128)
			except ConnectionAbortedError:
				raise Exception('Соединение разорвано')
			if not data:
				raise Exception('Сервер перестал отвечать')
			buffer = PacketBuffer(data)
			buffer.seek(0)
			size = types.VarInt.read(buffer)
			max_size = types.VarInt.read(buffer)
			if max_size == 0:
				packid = types.VarInt.read(buffer)
				if packid == 0x0E:
					data = types.Json.read(buffer)
					byte = buffer.read(1)
					uuid = types.UUID.read(buffer)
					if self.listen_chat != None:
						self.listen_chat(data,byte,uuid)

				if packid == 0x1F:
					KA = types.Long.read(buffer)
					# print(f'Сохранение соединения: {KA}')
					buffer = PacketBuffer()
					types.Long.write(KA,buffer)
					self.send(buffer,0x10)
			else:
				pass


#"yellow"
# username = 'IvanExe'
# text2 = string.pack(username)

# send(0,text)
# send(0,text2)
# #Login Success

# text3 = socket.recv(1024)
# print(recv(text3))