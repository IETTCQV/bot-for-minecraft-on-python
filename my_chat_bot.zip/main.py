from mcc import *

host = 'localhost' #"iepc.hopto.org"
port = 25565
username = 'jojo228'

main = Main()
main.connect(host,port,username)
chat_color = True

# прослушивание чата
def listen_chat(data,byte,uuid):
	text = ''
	if 'extra' in data:
		for obj in data['extra']:
			if chat_color and 'color' in obj:
				text += colorama.text(obj['text'],obj['color'])
			else:
				text += obj['text']
	else:
		text = data
	print(text)

main.listen_chat = listen_chat

# Сообщения в чат
while True:
	message = input()
	if message:
		buffer = PacketBuffer()
		types.String.write(message,buffer)
		main.send(buffer,0x03)